function evolveChoose(note, context) {
    addAction({
        type: "evolve_choose",
        note: note
    }, context);
}

function unitChoose(note, context){
    addAction({
        type: "unit_choose",
        note: note
    }, context);
}
function modeChoose(note, context){
    addAction({
        type: "mode_choose",
        note: note
    }, context);
}


